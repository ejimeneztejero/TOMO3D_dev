#ifndef _NR_UTILS_H_
#define _NR_UTILS_H_

void nrerror(char const* error_text);

#endif /* _NR_UTILS_H_ */
