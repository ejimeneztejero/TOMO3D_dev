#if !defined(TOMO_IN_HOUSE_OMP_SOLVER_HPP)
#define TOMO_IN_HOUSE_OMP_SOLVER_HPP

bool
select_in_house_omp_solver();

#endif
