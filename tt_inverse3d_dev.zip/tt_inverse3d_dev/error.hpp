/*
 * error.h
 *
 * Jun Korenaga, MIT/WHOI
 * January 1999
 */

#ifndef _MCONV_ERROR_H_
#define _MCONV_ERROR_H_

using namespace std;
#include <string>

void error(string s);

#endif /* _MCONV_ERROR_H_ */
