#include <iostream>

bool
select_pardiso_solver() {
    std::cerr << "PARDISO solver support was not enabled\n";
    return false;
}
