int main() {
    int* __restrict__ p = 0;
}
