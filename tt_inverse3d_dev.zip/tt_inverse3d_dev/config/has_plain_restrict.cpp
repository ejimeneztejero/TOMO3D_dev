int main() {
    int* restrict p = 0;
}
